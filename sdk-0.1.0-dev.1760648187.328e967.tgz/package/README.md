[![QVAC logo](https://tether-2.gitbook.io/qvac-by-tether-or-reference/y2AsIh94H9DJ1pIBCNj9/~gitbook/image?url=https%3A%2F%2F4184520186-files.gitbook.io%2F~%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Forganizations%252Fnu0sKQdYg5T0N88iY6ZN%252Fsites%252Fsite_Fu2B8%252Flogo%252Fto5sbpix5Uz6MFPzPwY1%252FVector.png%3Falt%3Dmedia%26token%3D27902e06-6941-413c-a199-1e2780444d1a&width=260&dpr=2&quality=100&sign=8040ed76&sv=2)](https://tether-2.gitbook.io/qvac-by-tether-or-reference/y2AsIh94H9DJ1pIBCNj9)

---

**QVAC** is an open-source, cross-platform system for building local-first, peer-to-peer **AI applications**. QVAC runs on [**Bare**](https://bare.pears.com) by [Holepunch](https://holepunch.to), a lightweight, cross-platform JavaScript runtime.

# QVAC SDK

**QVAC SDK** is the canonical entry point to QVAC. Written in TypeScript, it provides all QVAC capabilities through a unified interface while also abstracting away the complexity of running your application in a JS environment other than Bare.

For the comprehensive reference, [see official QVAC documentation](https://tether-2.gitbook.io/qvac-by-tether-or-reference/y2AsIh94H9DJ1pIBCNj9).

## Requirements

Supported JS environments: Bare, Node.js, Expo and Bun.

## Installation

### Steps

1. [Authenticate to Tether’s GitHub packages](#step-1-authenticate-to-tethers-github-packages)
2. [Install package and dependencies](#step-2-install-package-and-dependencies)

### Step 1: authenticate to Tether’s GitHub packages

1. [Create a GitHub personal access token (classic) with scope `read:packages`](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens#creating-a-personal-access-token-classic).

2. Add the token to your environment variables. For example, on macOS/Linux:

```bash
export NPM_TOKEN=<token_generated_in_previous_step>
```

3. In the root of your project, create file `.npmrc` with the following content:

```ini
@qvac:registry=https://registry.npmjs.org
//registry.npmjs.org/:_authToken=${NPM_TOKEN}
```

_Alternatively, you can create the `.npmrc` file in your home directory, for user-level (global) configuration._

4. Confirm authentication to Tether’s GitHub packages:

```bash
npm whoami --registry=https://npm.pkg.github.com
```

It should return your GitHub username.

### Step 2: Install package and dependencies

1. Install in your project using the package manager of your choice:

```bash
npm i @qvac/sdk
```

> [!TIP]  
> If you can't get the package via Tether's private GitHub package registry, see section [Build from source](#build-from-source).

#### On Linux

> [!IMPORTANT]  
> If you're on Linux ensure that the Vulkan SDK is installed (e.g. `apt install vulkan-sdk` on Ubuntu)

#### On Expo

1. Install the peer dependencies for Expo/React Native support:

```bash
npm i expo-file-system react-native-bare-kit
```

2. If you are on Android, bump your `minSdkVersion` to 29. You can do so by adding `ext { minSdkVersion=29 }` to your `android/build.gradle` or by using `expo-build-properties`.

3. Add the QVAC Expo plugin to your `app.json`:

```js
export default {
  expo: {
    plugins: ["qvac-sdk/expo-plugin"],
  },
};
```

4. Prebuild your project to generate the native files:

```bash
npx expo prebuild
```

5. Build and run it on a **physical device**:

```bash
npx expo run:ios --device
# or
npx expo run:android --device
```

> [!IMPORTANT]  
> Due to limitations with `llamacpp`, QVAC currently does not run on emulators. You **must** use a physical device.

## Quickstart

You can run the self-contained example below:

```js
import { loadModel, completion, unloadModel } from "@qvac/sdk";

// Load model into memory
const modelId = await loadModel(
  "pear://afa79ee07c0a138bb9f11bfaee771fb1bdfca8c82d961cff0474e49827bd1de3/Llama-3.2-1B-Instruct-Q4_0.gguf",
  {
    modelType: "llm",
  },
);

// Use the loaded model
const response = completion({
  modelId,
  history: [{ role: "user", content: "What is the capital of France?" }],
  stream: false,
});
const text = await response.text;
console.log(text);

// Enable KV cache for faster subsequent completions
const cachedResponse = completion({
  modelId,
  history: [
    { role: "user", content: "What is the capital of France?" },
    { role: "assistant", content: "The capital of France is Paris." },
    { role: "user", content: "What about Germany?" },
  ],
  stream: true,
  kvCache: true, // enables caching for faster inference
});

// You can use the loaded model multiple times

// Unload model to free up system resources
await unloadModel({ modelId });
```

**For more on how to use QVAC SDK, see [SDK at QVAC documentation](https://tether-2.gitbook.io/qvac-by-tether-or-reference/y2AsIh94H9DJ1pIBCNj9/sdk)**.

## Build from source

Use the [Bun](https://bun.sh/) package manager:

```bash
bun i
```

```bash
bun run build  # or `watch` for hotreload
```

```bash
bun run build:pack
```

This outputs a tarball under `dist/tetherto-qvac-sdk-{version}.tgz` that you can install in your project, e.g.:

```bash
npm i path/to/tetherto-qvac-sdk-0.0.1.tgz
```

## Examples

In the `./examples` subdirectory, you will find scripts demonstrating SDK usage. To try any of them:

1. Follow the steps in section [Build from source](#build-from-source).
2. Run using Bare, Node.js, or Bun as the runtime:

```bash
# With Bare
bun run bare:example dist/examples/path/to/example.js

# With Node
node dist/examples/path/to/example.js

# With bun, straight from source
bun run examples/path/to/example.ts
```

## Logging

QVAC SDK includes built-in log propagation that streams model logs from the worker process to your client application in real-time. This gives you visibility into what's happening inside your models during loading, inference, and other operations.

### Usage

Simply pass a logger when loading your model:

```js
import { getLogger, loadModel, completion, unloadModel } from "@qvac/sdk";

// Create a logger for your application
const logger = getLogger("my-app", {
  level: "debug", // Set log level
  transports: [
    // Optional: add custom log handlers
    (level, namespace, message) => {
      console.log(`[${level.toUpperCase()}] ${namespace}: ${message}`);
    },
  ],
});

// Load model with logging - RPC stream starts automatically
const modelId = await loadModel(
  "pear://afa79ee07c0a138bb9f11bfaee771fb1bdfca8c82d961cff0474e49827bd1de3/Llama-3.2-1B-Instruct-Q4_0.gguf",
  {
    modelType: "llm",
    logger, // Enable log streaming
  },
);

// Now you'll see model logs in your console as operations happen
for await (const token of completion({
  modelId,
  history: [{ role: "user", content: "Hello!" }],
}).tokenStream) {
  process.stdout.write(token);
}

await unloadModel({ modelId }); // Logging stream closes automatically
```

### What You'll See

When logging is enabled, you'll see real-time logs from the underlying model libraries:

```
[DEBUG] llamacpp:llm: Loading model weights...
[INFO] llamacpp:llm: Model loaded successfully, vocab_size=32000
[DEBUG] llamacpp:llm: Starting inference...
[DEBUG] llamacpp:llm: Inference completed, tokens=12
```

This works for all model types (LLM, Whisper, NMT, Embeddings) and provides valuable insight into model performance and behavior.

### Completion

- `llama.cpp` with local files: [`examples/llamacpp-filesystem.ts`](examples/llamacpp-filesystem.ts)
- `llama.cpp` with Hyperdrive: [`examples/llamacpp-hyperdrive.ts`](examples/llamacpp-hyperdrive.ts)
- `llama.cpp` with HTTP: [`examples/llamacpp-http.ts`](examples/llamacpp-http.ts)
- `llama.cpp` with file logging: [`examples/llamacpp-file-logging.ts`](examples/llamacpp-file-logging.ts)
- `llama.cpp` with tools/function calls: [`examples/llamacpp-tools.ts`](examples/llamacpp-tools.ts)
- `llama.cpp` with tools and routing: [`examples/llamacpp-tools-routing.ts`](examples/llamacpp-tools-routing.ts)
- `llama.cpp` with multimodal inference: [`examples/llamacpp-multimodal.ts`](examples/llamacpp-multimodal.ts)
- `llama.cpp` with KV cache: [`examples/kv-cache-example.ts`](examples/kv-cache-example.ts)

### Transcription

- `whisper.cpp` transcription: [`examples/whispercpp-transcription.ts`](examples/whispercpp-transcription.ts)
- Microphone recording: [`examples/microphone-record-transcription.ts`](examples/microphone-record-transcription.ts)

### Embeddings

- Embedding with Hyperdrive: [`examples/embed-hyperdrive.ts`](examples/embed-hyperdrive.ts)
- RAG example with HyperDB: [`examples/rag-hyperdb.ts`](examples/rag-hyperdb.ts)
- RAG with workspaces: [`examples/rag-hyperdb-workspaces.ts`](examples/rag-hyperdb-workspaces.ts) _(Demonstrates workspace isolation and chunking)_
- RAG example with LanceDB (desktop only): [`examples/rag-lancedb.ts`](examples/rag-lancedb.ts)
- RAG example with ChromaDB (desktop only): [`examples/rag-chromadb.ts`](examples/rag-chromadb.ts) _(Note: Requires ChromaDB server running)_
- RAG example with SQLite-Vector (desktop only): [`examples/rag-sqlite.ts`](examples/rag-sqlite.ts) _(Note: Uses SQLite-Vector WASM)_

### Translation

- Marian OPUS translation: [`examples/translation-opus.ts`](examples/translation-opus.ts)
- Indic language translation: [`examples/translation-indic.ts`](examples/translation-indic.ts)
- LLM-based translation: [`examples/translation-llm.ts`](examples/translation-llm.ts)

### Multimodel

- Load multiple models simultaneously: [`examples/multi-model-demo.ts`](examples/multi-model-demo.ts)

### Delegated inference

- Provider example: [`examples/delegated-inference/provider.ts`](examples/delegated-inference/provider.ts)
- Consumer example: [`examples/delegated-inference/consumer.ts`](examples/delegated-inference/consumer.ts)

**Note**: Set the `QVAC_HYPERSWARM_SEED` env var to ensure that the provider's uses the same keypair (i.e. the public key doesn't change on every run).
**Note**: ⚠️ Consumer does not handle reconnection yet.

### Download Lifecycle

- Pause and resume download: [`examples/download-with-cancel.ts`](examples/download-with-cancel.ts)

## Known issues

- **One off scripts don't terminate / hang**
  - Add a `process.exit()` call at the end, we're working on it.

- **I'm building my Expo app on iOS but I don't see logs from QVAC**
  - `npx expo start`
  - Open the `ios` folder in Xcode
  - Start the app with the play ▶️ button
  - View -> Debug area -> Activate console
  - You should see the system logs on the right pane
  - ⚠️ This only works when starting the app from Xcode
